const API_URL = "/api/items";

async function readApiResponse(response) {
  const raw = await response.text();
  if (!raw.trim()) {
    throw new Error("The server returned an empty response. Close the app, restart it with START_HERE.bat, and open http://localhost:3000 again.");
  }
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("The server did not return JSON. Make sure you opened http://localhost:3000 and kept the Node.js server running.");
  }
}
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const state = {
  items: [],
  view: "all",
  category: "all",
  search: "",
  type: "all",
  status: "open",
  toastTimer: null
};

const emojiByCategory = {
  "Electronics": "🎧",
  "Books & Notes": "📚",
  "ID Card": "🪪",
  "Accessories": "🎒",
  "Bottle": "🧴",
  "Clothing": "🧥",
  "Keys": "🔑",
  "Other": "📦"
};
const tones = ["tone-purple", "tone-green", "tone-orange", "tone-blue", "tone-pink", "tone-sand"];

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

function formatDate(value) {
  if (!value) return "Date not given";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function getFilteredItems() {
  return state.items.filter(item => {
    const matchesView = state.view === "all" || item.type === state.view;
    const matchesType = state.type === "all" || item.type === state.type;
    const matchesCategory = state.category === "all" ||
      item.category.toLowerCase() === state.category.toLowerCase();
    const matchesStatus = state.status === "all" || item.status === state.status;
    const query = state.search.toLowerCase();
    const matchesSearch = !query || [
      item.name, item.category, item.description, item.location
    ].some(value => String(value || "").toLowerCase().includes(query));
    return matchesView && matchesType && matchesCategory && matchesStatus && matchesSearch;
  }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function renderStats() {
  $("#lostCount").textContent = state.items.filter(item => item.type === "lost" && item.status === "open").length;
  $("#foundCount").textContent = state.items.filter(item => item.type === "found" && item.status === "open").length;
  $("#resolvedCount").textContent = state.items.filter(item => item.status === "resolved").length;
}

function renderItems() {
  const items = getFilteredItems();
  $("#resultCount").textContent = `${items.length} ${items.length === 1 ? "item" : "items"} found`;
  $("#itemsGrid").innerHTML = items.map((item, index) => {
    const isResolved = item.status === "resolved";
    const tone = tones[index % tones.length];
    const emoji = emojiByCategory[item.category] || "📦";
    const image = item.image
      ? `<img class="item-photo" src="${escapeHTML(item.image)}" alt="${escapeHTML(item.name)}">`
      : `<span class="item-emoji" aria-hidden="true">${emoji}</span>`;
    const statusText = isResolved ? "RESOLVED" : "OPEN";
    return `
      <article class="item-card ${isResolved ? "is-resolved" : ""}">
        <div class="item-visual ${tone}">
          ${image}
          <span class="type-pill ${item.type === "found" ? "found" : ""}">${item.type === "lost" ? "⌕ LOST ITEM" : "✓ FOUND ITEM"}</span>
          <span class="status-pill ${isResolved ? "resolved" : ""}">${statusText}</span>
        </div>
        <div class="item-content">
          <div class="item-category">${escapeHTML(item.category)}</div>
          <h3 class="item-title">${escapeHTML(item.name)}</h3>
          <p class="item-description">${escapeHTML(item.description)}</p>
          <div class="item-meta"><span class="location">⌖ ${escapeHTML(item.location)}</span><span>◷ ${escapeHTML(formatDate(item.date))}</span></div>
          <div class="item-actions">
            <button class="item-action" data-contact="${escapeHTML(item.id)}">${isResolved ? "View contact" : "Contact reporter"} ↗</button>
            <button class="item-action secondary" data-resolve="${escapeHTML(item.id)}">${isResolved ? "Reopen" : "Mark resolved"}</button>
          </div>
        </div>
      </article>`;
  }).join("");

  $("#itemsGrid").classList.toggle("hidden", items.length === 0);
  $("#emptyState").classList.toggle("hidden", items.length !== 0);
}

async function loadItems() {
  $("#itemsGrid").innerHTML = '<div class="loading-state">Finding campus listings<span>...</span></div>';
  try {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error("Server returned an error.");
    const data = await readApiResponse(response);
    state.items = data.items || [];
    renderStats();
    renderItems();
  } catch (error) {
    $("#itemsGrid").innerHTML = `<div class="loading-state">Couldn't load listings. Please make sure the Node.js server is running, then refresh the page.</div>`;
    $("#resultCount").textContent = "Connection issue";
    showToast("Could not connect to the server.");
  }
}

function applyFilters() {
  state.search = $("#searchInput").value.trim();
  state.type = $("#typeFilter").value;
  state.category = $("#categoryFilter").value;
  state.status = $("#statusFilter").value;
  renderItems();
}

function setView(view) {
  state.view = view;
  $$(".side-nav .nav-link").forEach(button => button.classList.remove("active"));
  if (view === "lost" || view === "found") {
    const button = $(`.nav-link[data-view="${view}"]`);
    if (button) button.classList.add("active");
  } else if (view === "all") {
    const button = $('.nav-link[data-view="all"]');
    if (button) button.classList.add("active");
  }
  $$(".category-link").forEach(button => button.classList.toggle("active", button.dataset.category === state.category));
  const titles = { all: "Recent listings", lost: "Lost items", found: "Found items" };
  $("#listingTitle").innerHTML = `${titles[view] || "Recent listings"} <span class="live-badge"><span></span> LIVE</span>`;
  $("#breadcrumbCurrent").textContent = view === "all" ? "Overview" : `${view[0].toUpperCase()}${view.slice(1)} items`;
  $("#pageTitle").innerHTML = view === "lost" ? 'Missing something?<br><span>Let’s find it together.</span>' :
    view === "found" ? 'Found something?<br><span>Help it get home.</span>' :
    'Lost something?<br><span>Let’s bring it home.</span>';
  applyFilters();
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}

function openModal(type = "lost") {
  $("#reportForm").reset();
  $("#reportDate").value = new Date().toISOString().slice(0, 10);
  const radio = $(`input[name="type"][value="${type}"]`);
  if (radio) radio.checked = true;
  $("#formError").classList.add("hidden");
  $("#reportModal").classList.remove("hidden");
  document.body.style.overflow = "hidden";
  setTimeout(() => $('input[name="name"]')?.focus(), 60);
}

function closeModal() {
  $("#reportModal").classList.add("hidden");
  document.body.style.overflow = "";
}

async function fileToDataURL(file) {
  if (!file) return "";
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
    throw new Error("Please select a JPG, PNG or WebP image.");
  }
  if (file.size > 65000) throw new Error("Please choose an image smaller than 65 KB.");
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read the selected image."));
    reader.readAsDataURL(file);
  });
}

$("#reportBtn").addEventListener("click", () => openModal(state.view === "found" ? "found" : "lost"));
$("#sideReportBtn").addEventListener("click", () => openModal("found"));
$("#closeModal").addEventListener("click", closeModal);
$("#cancelModal").addEventListener("click", closeModal);
$("#reportModal").addEventListener("click", event => {
  if (event.target === $("#reportModal")) closeModal();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeModal();
});

$("#searchInput").addEventListener("input", applyFilters);
$("#typeFilter").addEventListener("change", applyFilters);
$("#categoryFilter").addEventListener("change", applyFilters);
$("#statusFilter").addEventListener("change", applyFilters);

function clearFilters() {
  state.view = "all";
  state.category = "all";
  $("#searchInput").value = "";
  $("#typeFilter").value = "all";
  $("#categoryFilter").value = "all";
  $("#statusFilter").value = "open";
  setView("all");
  $("#categoryFilter").value = "all";
  state.category = "all";
  applyFilters();
}
$("#clearFiltersBtn").addEventListener("click", clearFilters);
$("#emptyClearBtn").addEventListener("click", clearFilters);
$("#browseBtn").addEventListener("click", () => $("#listings").scrollIntoView({ behavior: "smooth" }));

$$(".nav-link[data-view]").forEach(button => button.addEventListener("click", () => {
  state.category = "all";
  $("#categoryFilter").value = "all";
  setView(button.dataset.view);
  $("#sidebar").classList.remove("open");
}));
$$(".category-link").forEach(button => button.addEventListener("click", () => {
  state.category = button.dataset.category;
  $("#categoryFilter").value = state.category;
  state.view = "all";
  $$(".nav-link[data-view]").forEach(nav => nav.classList.toggle("active", nav.dataset.view === "all"));
  $$(".category-link").forEach(nav => nav.classList.toggle("active", nav === button));
  $("#breadcrumbCurrent").textContent = state.category;
  $("#listingTitle").innerHTML = `${escapeHTML(state.category)} <span class="live-badge"><span></span> LIVE</span>`;
  applyFilters();
  $("#listings").scrollIntoView({ behavior: "smooth" });
  $("#sidebar").classList.remove("open");
}));

$("#menuBtn").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

$("#reportForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = $("#submitReport");
  const errorBox = $("#formError");
  errorBox.classList.add("hidden");
  submit.disabled = true;
  submit.textContent = "Submitting...";

  try {
    const formData = new FormData(form);
    const photo = await fileToDataURL(formData.get("photo"));
    const payload = {
      type: formData.get("type"),
      name: formData.get("name"),
      category: formData.get("category"),
      date: formData.get("date"),
      location: formData.get("location"),
      description: formData.get("description"),
      contact: formData.get("contact"),
      image: photo
    };

    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await readApiResponse(response);
    if (!response.ok || !data.success) throw new Error(data.message || "Could not submit report.");

    closeModal();
    showToast(data.message || "Report submitted successfully!");
    await loadItems();
    $("#listings").scrollIntoView({ behavior: "smooth" });
  } catch (error) {
    errorBox.textContent = error.message || "Something went wrong. Please try again.";
    errorBox.classList.remove("hidden");
  } finally {
    submit.disabled = false;
    submit.innerHTML = 'Submit report <span>→</span>';
  }
});

$("#itemsGrid").addEventListener("click", async event => {
  const contactButton = event.target.closest("[data-contact]");
  const resolveButton = event.target.closest("[data-resolve]");

  if (contactButton) {
    const item = state.items.find(entry => entry.id === contactButton.dataset.contact);
    if (!item) return;
    const subject = encodeURIComponent(`Campus Lost & Found: ${item.name}`);
    const body = encodeURIComponent(`Hello,\n\nI am contacting you about the ${item.type} item "${item.name}" reported at ${item.location} on ${formatDate(item.date)}.\n\nPlease let me know how we can coordinate safely.\n\nThank you.`);
    window.location.href = `mailto:${encodeURIComponent(item.contact)}?subject=${subject}&body=${body}`;
  }

  if (resolveButton) {
    resolveButton.disabled = true;
    try {
      const response = await fetch(`${API_URL}/${encodeURIComponent(resolveButton.dataset.resolve)}/resolve`, { method: "PATCH" });
      const data = await readApiResponse(response);
      if (!response.ok || !data.success) throw new Error(data.message || "Could not update status.");
      showToast(data.message);
      await loadItems();
    } catch (error) {
      showToast(error.message || "Could not update item.");
    } finally {
      resolveButton.disabled = false;
    }
  }
});


// Front-end login/sign-up preview for the WDD project (not production authentication).
const authState = { name: "", email: "" };
function openLogin() {
  $("#loginModal").classList.remove("hidden");
  document.body.style.overflow = "hidden";
  $("#authEmail").focus();
}
function closeLogin() {
  $("#loginModal").classList.add("hidden");
  document.body.style.overflow = "";
}
function updateAuthMode() {
  const signup = $('input[name="authMode"]:checked').value === "signup";
  $("#nameField").classList.toggle("hidden", !signup);
  $("#authName").required = signup;
  $("#authPassword").autocomplete = signup ? "new-password" : "current-password";
  $("#authTitle");
  $("#loginTitle").textContent = signup ? "Create your account." : "Your campus, connected.";
  $("#authSubmit").innerHTML = signup ? 'Create account <span>→</span>' : 'Login <span>→</span>';
  $("#authError").classList.add("hidden");
}
$("#loginOpenBtn").addEventListener("click", openLogin);
$("#avatarBtn").addEventListener("click", () => authState.email ? (showToast(`Signed in as ${authState.email}`)) : openLogin());
$("#closeLoginModal").addEventListener("click", closeLogin);
$("#loginModal").addEventListener("click", event => { if (event.target === $("#loginModal")) closeLogin(); });
$$('input[name="authMode"]').forEach(input => input.addEventListener("change", updateAuthMode));
$("#loginForm").addEventListener("submit", event => {
  event.preventDefault();
  const signup = $('input[name="authMode"]:checked').value === "signup";
  const email = $("#authEmail").value.trim();
  const password = $("#authPassword").value;
  const name = $("#authName").value.trim();
  const error = $("#authError");
  if (!email || password.length < 6 || (signup && !name)) {
    error.textContent = "Please complete all required fields. Password must contain at least 6 characters.";
    error.classList.remove("hidden");
    return;
  }
  authState.email = email;
  authState.name = signup ? name : (email.split("@")[0] || "Student");
  $("#avatarBtn").textContent = authState.name.charAt(0).toUpperCase();
  $("#loginOpenBtn").textContent = "Signed in";
  closeLogin();
  $("#loginForm").reset();
  $('input[name="authMode"][value="login"]').checked = true;
  updateAuthMode();
  showToast(signup ? `Welcome to CampusFind, ${authState.name}!` : `Welcome back, ${authState.name}!`);
});

loadItems();
